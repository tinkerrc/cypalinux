<?php
### This file is part of the dictionaries-common package.
### It has been automatically generated.
### DO NOT EDIT!
$SQSPELL_APP = array (
  'American (hunspell)' => 'hunspell -a -d en_US   ',
  'American English (aspell)' => 'aspell -a -d en_US   ',
  'American English (ispell)' => 'ispell -a    -B -d american',
  'British English (aspell)' => 'aspell -a -d en_GB   ',
  'British English (ispell)' => 'ispell -a    -B -d british',
  'Canadian English (aspell)' => 'aspell -a -d en_CA   ',
  'English (aspell)' => 'aspell -a -d en   '
);
